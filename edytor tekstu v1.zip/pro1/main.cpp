#include <windows.h>
#include <commctrl.h>
//deklaracja zapowiadaj?ca
LRESULT CALLBACK NaszaProcedura (HWND hwnd, UINT message, WPARAM wpar, LPARAM lpar);
 
 #define POMOC 3
 #define NOWY 100
 #define OTWORZ 101
 //oto nasza procedura obs?ugi okna
LRESULT CALLBACK NaszaProcedura (HWND hwnd, UINT message, WPARAM wpar, LPARAM lpar)
{
	switch (message)
	{
			case WM_SYSCOMMAND:
				
			switch (wpar)
			{
				case SC_CLOSE:
				//wy?wietlenie okienka z informacj? i zako?czenie programu
					//MessageBox (hwnd, "czy chcesz wyj�� z programu?", "", MB_OK);
				PostQuitMessage (0);
				break;
 
				case SC_MINIMIZE:
				//MessageBox (hwnd, "czy chcesz zminimalizowa� to okno?", "", MB_OK);
				break;
 
				case SC_MAXIMIZE:
				//MessageBox (hwnd, "czy chcesz zmaksymalizowa� to okno?", "", MB_OK);
				break;
			}
	
 	 	 	 case WM_COMMAND:
 	 	 	 {
 	
 
            switch(LOWORD(wpar)) 
            { 
                case POMOC: 
                    break; 
 	 	 	 	 case NOWY: 
                  MessageBox (hwnd, "Jak zaczniesz nowy dokument stracisz wszelkie niezapisane dane. napewno chcesz to  zrobi�?", "Napewno?", MB_OKCANCEL | MB_ICONWARNING);
                    break; 
                case OTWORZ: 
                   MessageBox (hwnd, "Jak otworzysz nowy dokument wszelkie niezapisane dane zostan� utracone. napewno chcesz otworzy�?", "UWAGA", MB_OK | MB_ICONWARNING);
                    break; 
              
                default: 
                    break; 
 
            } 
 }
      
			default:
			return DefWindowProc (hwnd, message, wpar, lpar);
	}
}

HBITMAP CreateBitmapMask( HBITMAP hbmColour, COLORREF crTransparent )
{
    HDC hdcMem, hdcMem2;
    HBITMAP hbmMask, hbmOld, hbmOld2;
    BITMAP bm;
    
    GetObject( hbmColour, sizeof( BITMAP ), & bm );
    hbmMask = CreateBitmap( bm.bmWidth, bm.bmHeight, 1, 1, NULL );
    
    hdcMem = CreateCompatibleDC( NULL );
    hdcMem2 = CreateCompatibleDC( NULL );
    
    hbmOld =( HBITMAP ) SelectObject( hdcMem, hbmColour );
    hbmOld2 =( HBITMAP ) SelectObject( hdcMem2, hbmMask );
    
    SetBkColor( hdcMem, crTransparent );
    
    BitBlt( hdcMem2, 0, 0, bm.bmWidth, bm.bmHeight, hdcMem, 0, 0, SRCCOPY );
    BitBlt( hdcMem, 0, 0, bm.bmWidth, bm.bmHeight, hdcMem2, 0, 0, SRCINVERT );
    
    SelectObject( hdcMem, hbmOld );
    SelectObject( hdcMem2, hbmOld2 );
    DeleteDC( hdcMem );
    DeleteDC( hdcMem2 );
    
    return hbmMask;
}
 
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpsCmdLine, int nMode)
{
	HWND hEdycja, hOkno;
	MSG message;
	WNDCLASS okno;
    HMENU hMenu = LoadMenu( hInstance, MAKEINTRESOURCE( 200 ) );
	okno.hInstance = hInstance;
	okno.lpszClassName = "klasa g??wna";
	okno.lpfnWndProc = NaszaProcedura; //tutaj pojawia si? nowo??!!
	okno.lpszMenuName = NULL;
	okno.style = 0;
	okno.hIcon = LoadIcon (NULL, IDI_WINLOGO);
	okno.hCursor = LoadCursor (NULL, IDC_ARROW);
	okno.hbrBackground = (HBRUSH) GetStockObject (BLACK_BRUSH);
	okno.cbClsExtra = 0;
	okno.cbWndExtra = 0;
	okno.lpszMenuName="Nazwa_menu";
	if(!RegisterClass (&okno)) return 0;
	hOkno = CreateWindow ("klasa g??wna", "?okno :p",
		WS_OVERLAPPEDWINDOW, 100,100,600,700,
		NULL, NULL, hInstance, NULL);
	ShowWindow (hOkno, SW_SHOW);
//hEdycja=CreateWindowEx(WS_EX_CLIENTEDGE,WC_EDIT,"",WS_CHILD|WS_VISIBLE,20,20,400,500,hOkno,0,hInstance,0); 
//HWND hText = CreateWindowEx( WS_EX_CLIENTEDGE, "EDIT", NULL, WS_CHILD | WS_VISIBLE | WS_BORDER |
//WS_VSCROLL | ES_MULTILINE | ES_AUTOVSCROLL, 5, 5, 150, 150, hOkno, NULL, hInstance, NULL );

//HBITMAP hbmObraz;
//hbmObraz =( HBITMAP ) LoadImage( NULL, "c:\\mine\\mine.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE );

/*	HBITMAP hbmObraz, hbmOld, hbmMaska;
	hbmObraz =( HBITMAP ) LoadImage( NULL, "mine.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE );
	hbmMaska = CreateBitmapMask( hbmObraz, RGB( 0, 255, 0 ) );
	HDC hdc = GetDC( hOkno ), hdcNowy = CreateCompatibleDC( hdc );
	BITMAP bmInfo;

	GetObject( hbmObraz, sizeof( bmInfo ), & bmInfo );
	hbmOld =( HBITMAP ) SelectObject( hdcNowy, hbmMaska );

	BitBlt( hdc, 0, 0, bmInfo.bmWidth, bmInfo.bmHeight, hdcNowy, 0, 0, SRCAND );
	SelectObject( hdcNowy, hbmObraz );
	BitBlt( hdc, 0, 0, bmInfo.bmWidth, bmInfo.bmHeight, hdcNowy, 0, 0, SRCPAINT );

	ReleaseDC( hOkno, hdc );
	SelectObject( hdcNowy, hbmOld );
	DeleteDC( hdcNowy );
	DeleteObject( hbmMaska );
	DeleteObject( hbmObraz );*/

HBITMAP hbmikonanew =( HBITMAP ) LoadImage( hInstance, "ikona-NEW.bmp",
IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT );
SetMenuItemBitmaps( hMenu, 100, MF_BYCOMMAND, hbmikonanew, hbmikonanew );
HWND g_hPrzycisk;
g_hPrzycisk = CreateWindowEx( 0, "BUTTON", "Zapisz", WS_CHILD | WS_VISIBLE,
100, 100, 200, 50, hOkno, NULL, hInstance, NULL );
g_hPrzycisk = CreateWindowEx( 0, "BUTTON", "Otw�rz", WS_CHILD | WS_VISIBLE,
100, 150, 200, 50, hOkno, NULL, hInstance, NULL );
g_hPrzycisk = CreateWindowEx( 0, "BUTTON", "Nowy", WS_CHILD | WS_VISIBLE,
100, 200, 200, 50, hOkno, NULL, hInstance, NULL );



HWND hText = CreateWindowEx( WS_EX_CLIENTEDGE, "EDIT", NULL, WS_CHILD | WS_VISIBLE | WS_BORDER |
WS_VSCROLL | ES_MULTILINE | ES_AUTOVSCROLL, 500, 5, 700, 700, hOkno, NULL, hInstance, NULL );
	while (GetMessage (&message, NULL, 0, 0))
	{
		TranslateMessage (&message);
		DispatchMessage (&message);
	}
}